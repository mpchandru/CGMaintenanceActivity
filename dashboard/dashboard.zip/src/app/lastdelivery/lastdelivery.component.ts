import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lastdelivery',
  templateUrl: './lastdelivery.component.html',
  styleUrls: ['./lastdelivery.component.css']
})
export class LastdeliveryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
