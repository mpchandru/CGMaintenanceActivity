import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planeddelivery',
  templateUrl: './planeddelivery.component.html',
  styleUrls: ['./planeddelivery.component.css']
})
export class PlaneddeliveryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
