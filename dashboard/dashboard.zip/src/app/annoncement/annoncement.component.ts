import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-annoncement',
  templateUrl: './annoncement.component.html',
  styleUrls: ['./annoncement.component.css']
})
export class AnnoncementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
