import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bdannoncement',
  templateUrl: './bdannoncement.component.html',
  styleUrls: ['./bdannoncement.component.css']
})
export class BdannoncementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
