import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teamchallenge',
  templateUrl: './teamchallenge.component.html',
  styleUrls: ['./teamchallenge.component.css']
})
export class TeamchallengeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
