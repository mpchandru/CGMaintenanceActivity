import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chartview',
  templateUrl: './chartview.component.html',
  styleUrls: ['./chartview.component.css']
})
export class ChartviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
